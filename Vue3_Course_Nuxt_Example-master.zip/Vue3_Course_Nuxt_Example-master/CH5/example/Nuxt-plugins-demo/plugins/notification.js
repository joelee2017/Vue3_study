import Vue from "vue";
// import Notifications from "vue-notification";

import Notifications from "vue-notification/dist/ssr.js";
Vue.use(Notifications);
