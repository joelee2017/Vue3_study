<template>
  <h1>500 sorry</h1>
</template>

<script>
export default {};
</script>

<style></style>
