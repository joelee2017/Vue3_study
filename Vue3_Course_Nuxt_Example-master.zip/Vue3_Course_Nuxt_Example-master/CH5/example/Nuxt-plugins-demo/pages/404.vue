<template>
  <h1>404 找不到頁面</h1>
</template>

<script>
export default {};
</script>

<style></style>
