<script>
export default {};
</script>

<template>
  <div>
    <h1 class="title">Guide</h1>
    <a href="https://next.router.vuejs.org/guide/#html" class="text">
      https://next.router.vuejs.org/guide/#html
    </a>
  </div>
</template>

<style scoped>
.title {
  margin-top: 30px;
  font-size: 40px;
}
.text {
  font-size: 20px;
  margin-top: 10px;
  color: cadetblue;
}
</style>
