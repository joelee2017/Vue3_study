<script>
export default {};
</script>

<template>
  <div>
    <h1 class="title">GitHub</h1>
    <a href="https://github.com/vuejs/vue-router-next" class="text">
      https://github.com/vuejs/vue-router-next
    </a>
  </div>
</template>

<style scoped>
.title {
  margin-top: 30px;
  font-size: 40px;
}
.text {
  font-size: 20px;
  margin-top: 10px;
  color: cadetblue;
}
</style>
