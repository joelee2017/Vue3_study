<script>
export default {};
</script>

<template>
  <div>
    <h1 class="title">Reference</h1>
    <a href="https://next.router.vuejs.org/api/#router-link-props" class="text">
      https://next.router.vuejs.org/api/#router-link-props
    </a>
  </div>
</template>

<style scoped>
.title {
  margin-top: 30px;
  font-size: 40px;
}
.text {
  font-size: 20px;
  margin-top: 10px;
  color: cadetblue;
}
</style>
