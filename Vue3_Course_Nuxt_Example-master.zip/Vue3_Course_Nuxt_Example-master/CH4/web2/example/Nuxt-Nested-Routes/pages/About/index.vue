<script>
export default {};
</script>
<template>
  <div id="aboutHome">
    <img alt="Vue logo" src="../../assets/logo.png" />
    <h1>歡迎來到關於我們</h1>
  </div>
</template>

<style scoped>
#aboutHome {
  margin-top: 40px;
}
</style>
