<script>
export default {};
</script>

<template>
  <div>
    <h1 class="title">Changelog</h1>
    <a
      href="https://github.com/vuejs/vue-router-next/blob/master/CHANGELOG.md"
      class="text"
    >
      https://github.com/vuejs/vue-router-next/blob/master/CHANGELOG.md
    </a>
  </div>
</template>

<style scoped>
.title {
  margin-top: 30px;
  font-size: 40px;
}
.text {
  font-size: 20px;
  margin-top: 10px;
  color: cadetblue;
}
</style>
