// state
export const state = () => ({
  name: "Mike",
  age: 12
});
// actions
export const actions = {
  handUserLog() {
    console.log("User data");
  }
};
// mutations
export const mutations = {};
// getters
export const getters = {};
