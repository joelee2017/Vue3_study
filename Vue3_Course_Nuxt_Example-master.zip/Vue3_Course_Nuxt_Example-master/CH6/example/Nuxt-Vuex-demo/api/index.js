import { getphotoData } from "./photoReq.js";

export const apiGetPhotoData = getphotoData;
