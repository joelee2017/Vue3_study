<script>
export default {};
</script>

<template>
  <div class="content">
    <Nuxt />
  </div>
</template>

<style>
html,
body {
  width: 100%;
  height: 100%;
  background-color: slategrey;
}

*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
}
#__nuxt,
#__layout {
  width: 100%;
  height: 100%;
}
.content {
  width: 100%;
  height: 100%;
}
</style>
