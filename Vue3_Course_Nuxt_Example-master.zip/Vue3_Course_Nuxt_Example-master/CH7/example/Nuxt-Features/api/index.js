import { postLoginRequest, postTestToken } from "./authRequest.js";

export const apiPostLoginRequest = postLoginRequest;
export const apiPostTestToken = postTestToken;
