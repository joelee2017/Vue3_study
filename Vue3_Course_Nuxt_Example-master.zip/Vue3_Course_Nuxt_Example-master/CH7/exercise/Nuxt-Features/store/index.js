// state
export const state = () => ({});

// actions
export const actions = {};

// mutations
export const mutations = {};

// getters
export const getters = {};
